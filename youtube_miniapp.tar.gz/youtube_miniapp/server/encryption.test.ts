import { describe, expect, it } from "vitest";
import { encryptApiKey, decryptApiKey } from "./encryption";

describe("API Key Encryption", () => {
  it("should encrypt and decrypt API key correctly", () => {
    const originalKey = "AIzaSyDemoKey123456789";
    const encrypted = encryptApiKey(originalKey);
    const decrypted = decryptApiKey(encrypted);

    expect(decrypted).toBe(originalKey);
    expect(encrypted).not.toBe(originalKey);
  });

  it("should produce different encrypted values for same input", () => {
    const apiKey = "AIzaSyTestKey987654321";
    const encrypted1 = encryptApiKey(apiKey);
    const encrypted2 = encryptApiKey(apiKey);

    // Both should decrypt to same value
    expect(decryptApiKey(encrypted1)).toBe(apiKey);
    expect(decryptApiKey(encrypted2)).toBe(apiKey);
  });

  it("should handle empty string", () => {
    const encrypted = encryptApiKey("");
    const decrypted = decryptApiKey(encrypted);
    expect(decrypted).toBe("");
  });

  it("should handle long API keys", () => {
    const longKey = "AIzaSy" + "a".repeat(100);
    const encrypted = encryptApiKey(longKey);
    const decrypted = decryptApiKey(encrypted);
    expect(decrypted).toBe(longKey);
  });
});
