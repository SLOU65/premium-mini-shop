import CryptoJS from 'crypto-js';

// Use JWT_SECRET as encryption key (already available in env)
const ENCRYPTION_KEY = process.env.JWT_SECRET || 'default-secret-key-change-in-production';

/**
 * Encrypt API key using AES-256
 */
export function encryptApiKey(apiKey: string): string {
  return CryptoJS.AES.encrypt(apiKey, ENCRYPTION_KEY).toString();
}

/**
 * Decrypt API key
 */
export function decryptApiKey(encryptedKey: string): string {
  const bytes = CryptoJS.AES.decrypt(encryptedKey, ENCRYPTION_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
}
