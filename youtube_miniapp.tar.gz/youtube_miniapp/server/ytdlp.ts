import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface VideoFormat {
  format_id: string;
  ext: string;
  quality: string;
  filesize?: number;
  url: string;
  format_note?: string;
  height?: number;
  width?: number;
  fps?: number;
  vcodec?: string;
  acodec?: string;
}

export interface VideoInfo {
  id: string;
  title: string;
  thumbnail: string;
  duration: number;
  uploader: string;
  view_count: number;
  like_count?: number;
  description: string;
  upload_date: string;
  formats: VideoFormat[];
  direct_url?: string;
}

/**
 * Get video information and direct download links using yt-dlp
 */
export async function getVideoDownloadInfo(videoUrl: string): Promise<VideoInfo> {
  try {
    // Get JSON info from yt-dlp
    const { stdout } = await execAsync(
      `yt-dlp -j --no-warnings "${videoUrl}"`,
      { maxBuffer: 10 * 1024 * 1024 } // 10MB buffer
    );

    const info = JSON.parse(stdout);

    // Extract and format the data
    const videoInfo: VideoInfo = {
      id: info.id,
      title: info.title,
      thumbnail: info.thumbnail,
      duration: info.duration,
      uploader: info.uploader,
      view_count: info.view_count,
      like_count: info.like_count,
      description: info.description,
      upload_date: info.upload_date,
      formats: info.formats?.map((f: any) => ({
        format_id: f.format_id,
        ext: f.ext,
        quality: f.quality || f.format_note || 'unknown',
        filesize: f.filesize,
        url: f.url,
        format_note: f.format_note,
        height: f.height,
        width: f.width,
        fps: f.fps,
        vcodec: f.vcodec,
        acodec: f.acodec,
      })) || [],
    };

    return videoInfo;
  } catch (error: any) {
    throw new Error(`Failed to get video info: ${error.message}`);
  }
}

/**
 * Get best quality direct download URL
 */
export async function getBestVideoUrl(videoUrl: string): Promise<string> {
  try {
    const { stdout } = await execAsync(
      `yt-dlp -f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best" --get-url "${videoUrl}"`,
      { maxBuffer: 1024 * 1024 }
    );

    return stdout.trim().split('\n')[0] || '';
  } catch (error: any) {
    throw new Error(`Failed to get video URL: ${error.message}`);
  }
}

/**
 * Get audio-only download URL (for MP3 conversion)
 */
export async function getAudioUrl(videoUrl: string): Promise<string> {
  try {
    const { stdout } = await execAsync(
      `yt-dlp -f "bestaudio[ext=m4a]/bestaudio" --get-url "${videoUrl}"`,
      { maxBuffer: 1024 * 1024 }
    );

    return stdout.trim();
  } catch (error: any) {
    throw new Error(`Failed to get audio URL: ${error.message}`);
  }
}

/**
 * Check if yt-dlp is installed
 */
export async function checkYtDlpInstalled(): Promise<boolean> {
  try {
    await execAsync('yt-dlp --version');
    return true;
  } catch {
    return false;
  }
}
