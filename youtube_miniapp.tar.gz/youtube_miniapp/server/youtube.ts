import { google } from 'googleapis';

/**
 * Create YouTube API client with user's API key
 */
export function createYouTubeClient(apiKey: string) {
  return google.youtube({
    version: 'v3',
    auth: apiKey,
  });
}

/**
 * Search for videos, channels, or playlists
 */
export async function searchYouTube(
  apiKey: string, 
  query: string, 
  type: 'video' | 'channel' | 'playlist' = 'video', 
  maxResults: number = 10,
  pageToken?: string,
  order?: 'relevance' | 'date' | 'viewCount' | 'rating',
  publishedAfter?: string,
  videoDuration?: 'short' | 'medium' | 'long'
) {
  const youtube = createYouTubeClient(apiKey);
  
  const params: any = {
    part: ['snippet'],
    q: query,
    type: [type],
    maxResults,
  };
  
  if (pageToken) params.pageToken = pageToken;
  if (order) params.order = order;
  if (publishedAfter) params.publishedAfter = publishedAfter;
  if (videoDuration) params.videoDuration = videoDuration;
  
  const response = await youtube.search.list(params);

  return response.data;
}

/**
 * Get detailed video information
 */
export async function getVideoDetails(apiKey: string, videoId: string) {
  const youtube = createYouTubeClient(apiKey);
  
  const response = await youtube.videos.list({
    part: ['snippet', 'contentDetails', 'statistics', 'status'],
    id: [videoId],
  });

  return response.data.items?.[0];
}

/**
 * Get channel information
 */
export async function getChannelDetails(apiKey: string, channelId: string) {
  const youtube = createYouTubeClient(apiKey);
  
  const response = await youtube.channels.list({
    part: ['snippet', 'contentDetails', 'statistics', 'brandingSettings'],
    id: [channelId],
  });

  return response.data.items?.[0];
}

/**
 * Get video comments
 */
export async function getVideoComments(apiKey: string, videoId: string, maxResults: number = 20) {
  const youtube = createYouTubeClient(apiKey);
  
  const response = await youtube.commentThreads.list({
    part: ['snippet'],
    videoId,
    maxResults,
    order: 'relevance',
  });

  return response.data;
}

/**
 * Get channel playlists
 */
export async function getChannelPlaylists(apiKey: string, channelId: string, maxResults: number = 10) {
  const youtube = createYouTubeClient(apiKey);
  
  const response = await youtube.playlists.list({
    part: ['snippet', 'contentDetails'],
    channelId,
    maxResults,
  });

  return response.data;
}

/**
 * Get playlist items
 */
export async function getPlaylistItems(apiKey: string, playlistId: string, maxResults: number = 50) {
  const youtube = createYouTubeClient(apiKey);
  
  const response = await youtube.playlistItems.list({
    part: ['snippet', 'contentDetails'],
    playlistId,
    maxResults,
  });

  return response.data;
}

/**
 * Validate YouTube API key by making a simple request
 */
export async function validateApiKey(apiKey: string): Promise<boolean> {
  try {
    const youtube = createYouTubeClient(apiKey);
    await youtube.search.list({
      part: ['snippet'],
      q: 'test',
      maxResults: 1,
    });
    return true;
  } catch (error) {
    return false;
  }
}
