import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { 
  saveYoutubeApiKey, 
  getActiveYoutubeApiKey, 
  deleteYoutubeApiKey,
  addSearchHistory,
  getUserSearchHistory 
} from "./db";
import { encryptApiKey, decryptApiKey } from "./encryption";
import { 
  validateApiKey, 
  searchYouTube, 
  getVideoDetails, 
  getChannelDetails,
  getVideoComments,
  getChannelPlaylists,
  getPlaylistItems
} from "./youtube";
import { getVideoDownloadInfo, getBestVideoUrl, getAudioUrl } from "./ytdlp";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  youtube: router({
    // API Key Management
    saveApiKey: protectedProcedure
      .input(z.object({ apiKey: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        // Validate the API key first
        const isValid = await validateApiKey(input.apiKey);
        if (!isValid) {
          throw new Error('Invalid YouTube API key');
        }

        const encryptedKey = encryptApiKey(input.apiKey);
        await saveYoutubeApiKey(ctx.user.id, encryptedKey);
        
        return { success: true };
      }),

    getApiKeyStatus: protectedProcedure
      .query(async ({ ctx }) => {
        const apiKeyRecord = await getActiveYoutubeApiKey(ctx.user.id);
        return { 
          hasApiKey: !!apiKeyRecord,
          createdAt: apiKeyRecord?.createdAt 
        };
      }),

    deleteApiKey: protectedProcedure
      .mutation(async ({ ctx }) => {
        await deleteYoutubeApiKey(ctx.user.id);
        return { success: true };
      }),

    // Search
    search: protectedProcedure
      .input(z.object({
        query: z.string().min(1),
        type: z.enum(['video', 'channel', 'playlist']).default('video'),
        maxResults: z.number().min(1).max(1000).default(20),
        pageToken: z.string().optional(),
        order: z.enum(['relevance', 'date', 'viewCount', 'rating']).optional(),
        publishedAfter: z.string().optional(),
        videoDuration: z.enum(['short', 'medium', 'long']).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const apiKeyRecord = await getActiveYoutubeApiKey(ctx.user.id);
        if (!apiKeyRecord) {
          throw new Error('No API key configured');
        }

        const apiKey = decryptApiKey(apiKeyRecord.encryptedKey);
        
        // YouTube API limits to 50 results per request
        // For requests > 50, we need to fetch multiple pages
        const requestsNeeded = Math.ceil(input.maxResults / 50);
        let allResults: any[] = [];
        let pageToken: string | undefined = input.pageToken;
        
        for (let i = 0; i < requestsNeeded && allResults.length < input.maxResults; i++) {
          const batchSize = Math.min(50, input.maxResults - allResults.length);
          const results = await searchYouTube(
            apiKey, 
            input.query, 
            input.type, 
            batchSize,
            pageToken,
            input.order,
            input.publishedAfter,
            input.videoDuration
          );
          
          if (results.items) {
            allResults = allResults.concat(results.items);
          }
          pageToken = results.nextPageToken || undefined;
          
          // Stop if no more results
          if (!pageToken) break;
        }

        // Save to history
        await addSearchHistory({
          userId: ctx.user.id,
          queryType: 'search',
          queryData: JSON.stringify(input),
        });

        return {
          items: allResults.slice(0, input.maxResults),
          nextPageToken: pageToken,
          totalResults: allResults.length,
        };
      }),

    // Video Details
    getVideo: protectedProcedure
      .input(z.object({ videoId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const apiKeyRecord = await getActiveYoutubeApiKey(ctx.user.id);
        if (!apiKeyRecord) {
          throw new Error('No API key configured');
        }

        const apiKey = decryptApiKey(apiKeyRecord.encryptedKey);
        const video = await getVideoDetails(apiKey, input.videoId);

        // Save to history
        if (video) {
          await addSearchHistory({
            userId: ctx.user.id,
            queryType: 'video',
            queryData: JSON.stringify({ videoId: input.videoId }),
            videoId: input.videoId,
            videoTitle: video.snippet?.title || null,
            channelId: video.snippet?.channelId || null,
            channelTitle: video.snippet?.channelTitle || null,
            thumbnail: video.snippet?.thumbnails?.default?.url || null,
          });
        }

        return video;
      }),

    // Channel Details
    getChannel: protectedProcedure
      .input(z.object({ channelId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const apiKeyRecord = await getActiveYoutubeApiKey(ctx.user.id);
        if (!apiKeyRecord) {
          throw new Error('No API key configured');
        }

        const apiKey = decryptApiKey(apiKeyRecord.encryptedKey);
        const channel = await getChannelDetails(apiKey, input.channelId);

        // Save to history
        if (channel) {
          await addSearchHistory({
            userId: ctx.user.id,
            queryType: 'channel',
            queryData: JSON.stringify({ channelId: input.channelId }),
            channelId: input.channelId,
            channelTitle: channel.snippet?.title || null,
            thumbnail: channel.snippet?.thumbnails?.default?.url || null,
          });
        }

        return channel;
      }),

    // Comments
    getComments: protectedProcedure
      .input(z.object({ 
        videoId: z.string(),
        maxResults: z.number().min(1).max(100).default(20),
      }))
      .mutation(async ({ ctx, input }) => {
        const apiKeyRecord = await getActiveYoutubeApiKey(ctx.user.id);
        if (!apiKeyRecord) {
          throw new Error('No API key configured');
        }

        const apiKey = decryptApiKey(apiKeyRecord.encryptedKey);
        return await getVideoComments(apiKey, input.videoId, input.maxResults);
      }),

    // Playlists
    getChannelPlaylists: protectedProcedure
      .input(z.object({ 
        channelId: z.string(),
        maxResults: z.number().min(1).max(50).default(10),
      }))
      .mutation(async ({ ctx, input }) => {
        const apiKeyRecord = await getActiveYoutubeApiKey(ctx.user.id);
        if (!apiKeyRecord) {
          throw new Error('No API key configured');
        }

        const apiKey = decryptApiKey(apiKeyRecord.encryptedKey);
        return await getChannelPlaylists(apiKey, input.channelId, input.maxResults);
      }),

    getPlaylistItems: protectedProcedure
      .input(z.object({ 
        playlistId: z.string(),
        maxResults: z.number().min(1).max(50).default(50),
      }))
      .mutation(async ({ ctx, input }) => {
        const apiKeyRecord = await getActiveYoutubeApiKey(ctx.user.id);
        if (!apiKeyRecord) {
          throw new Error('No API key configured');
        }

        const apiKey = decryptApiKey(apiKeyRecord.encryptedKey);
        return await getPlaylistItems(apiKey, input.playlistId, input.maxResults);
      }),

    // Download Links (yt-dlp)
    getDownloadInfo: protectedProcedure
      .input(z.object({ videoUrl: z.string().url() }))
      .mutation(async ({ input }) => {
        return await getVideoDownloadInfo(input.videoUrl);
      }),

    getBestVideoUrl: protectedProcedure
      .input(z.object({ videoUrl: z.string().url() }))
      .mutation(async ({ input }) => {
        return await getBestVideoUrl(input.videoUrl);
      }),

    getAudioUrl: protectedProcedure
      .input(z.object({ videoUrl: z.string().url() }))
      .mutation(async ({ input }) => {
        return await getAudioUrl(input.videoUrl);
      }),

    // History
    getHistory: protectedProcedure
      .input(z.object({ limit: z.number().min(1).max(100).default(20) }))
      .query(async ({ ctx, input }) => {
        return await getUserSearchHistory(ctx.user.id, input.limit);
      }),
  }),
});

export type AppRouter = typeof appRouter;
