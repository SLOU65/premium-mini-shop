import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Loader2, History } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function HistoryPage() {
  const { t } = useLanguage();
  const [, setLocation] = useLocation();

  const { data: history, isLoading } = trpc.youtube.getHistory.useQuery({ limit: 20 });

  const handleItemClick = (item: any) => {
    const data = JSON.parse(item.queryData);
    if (item.queryType === 'video' && item.videoId) {
      setLocation(`/video/${item.videoId}`);
    } else if (item.queryType === 'channel' && item.channelId) {
      setLocation(`/channel/${item.channelId}`);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      <div className="container max-w-4xl py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t('back')}
          </Button>
        </Link>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="w-6 h-6" />
              {t('historyTitle')}
            </CardTitle>
            <CardDescription>
              {history && history.length > 0 ? `${history.length} ${t('history')}` : t('noHistory')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!history || history.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {t('noHistory')}
              </div>
            ) : (
              <div className="space-y-3">
                {history.map((item) => (
                  <Card
                    key={item.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => handleItemClick(item)}
                  >
                    <div className="flex gap-4 p-4">
                      {item.thumbnail && (
                        <img
                          src={item.thumbnail}
                          alt={item.videoTitle || item.channelTitle || ''}
                          className="w-32 h-20 object-cover rounded"
                        />
                      )}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                            {item.queryType}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {new Date(item.createdAt).toLocaleString()}
                          </span>
                        </div>
                        {item.videoTitle && (
                          <h4 className="font-semibold line-clamp-1">{item.videoTitle}</h4>
                        )}
                        {item.channelTitle && (
                          <p className="text-sm text-muted-foreground">{item.channelTitle}</p>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
