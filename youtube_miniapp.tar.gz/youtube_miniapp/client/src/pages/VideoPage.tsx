import { useState, useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Link, useParams } from "wouter";
import { ArrowLeft, Loader2, Eye, ThumbsUp, MessageSquare, ExternalLink } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function VideoPage() {
  const { videoId } = useParams<{ videoId: string }>();
  const { t } = useLanguage();

  const videoMutation = trpc.youtube.getVideo.useMutation({
    onError: (error) => {
      toast.error(error.message || t('errorLoadingData'));
    },
  });

  useEffect(() => {
    if (videoId) {
      videoMutation.mutate({ videoId });
    }
  }, [videoId]);

  const video = videoMutation.data;
  const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

  const formatNumber = (num?: number) => {
    if (!num) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return '0:00';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  if (videoMutation.isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!video) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">{t('errorLoadingData')}</p>
          <Link href="/search">
            <Button className="mt-4">{t('back')}</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      <div className="container max-w-4xl py-8">
        <Link href="/search">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t('back')}
          </Button>
        </Link>

        <Card>
          <CardHeader>
            <CardTitle>{video.snippet?.title}</CardTitle>
            <CardDescription>{video.snippet?.channelTitle}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {video.snippet?.thumbnails?.high?.url && (
              <div className="relative w-full bg-black rounded-lg overflow-hidden aspect-video">
                <img
                  src={video.snippet.thumbnails.high.url}
                  alt={video.snippet.title || ''}
                  className="w-full h-full object-cover"
                />
                <a
                  href={videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute inset-0 flex items-center justify-center bg-black/40 hover:bg-black/60 transition-colors"
                >
                  <div className="text-white text-center">
                    <div className="text-4xl mb-2">▶</div>
                    <div className="text-sm">Открыть на YouTube</div>
                  </div>
                </a>
              </div>
            )}

            <div className="flex flex-wrap gap-3">
              <Badge variant="secondary" className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                {formatNumber(video.statistics?.viewCount as any)} {t('views')}
              </Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <ThumbsUp className="w-4 h-4" />
                {formatNumber(video.statistics?.likeCount as any)} {t('likes')}
              </Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <MessageSquare className="w-4 h-4" />
                {formatNumber(video.statistics?.commentCount as any)} {t('comments')}
              </Badge>
              {video.contentDetails?.duration && (
                <Badge variant="secondary">
                  {formatDuration(
                    parseInt(video.contentDetails.duration.replace(/PT(\d+)H(\d+)M(\d+)S/, (_, h, m, s) => 
                      (parseInt(h || '0') * 3600 + parseInt(m || '0') * 60 + parseInt(s || '0')).toString()
                    ))
                  )}
                </Badge>
              )}
            </div>

            {video.snippet?.publishedAt && (
              <div className="text-sm text-muted-foreground">
                {t('published')}: {new Date(video.snippet.publishedAt).toLocaleDateString()}
              </div>
            )}

            <Separator />

            <div>
              <h3 className="font-semibold mb-2">{t('description')}</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-6">
                {video.snippet?.description}
              </p>
            </div>

            {video.snippet?.tags && video.snippet.tags.length > 0 && (
              <>
                <Separator />
                <div>
                  <h3 className="font-semibold mb-2">{t('tags')}</h3>
                  <div className="flex flex-wrap gap-2">
                    {video.snippet.tags.slice(0, 10).map((tag: string, idx: number) => (
                      <Badge key={idx} variant="outline">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </>
            )}

            <Separator />

            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Смотреть видео</h3>
              <a
                href={videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                Открыть на YouTube
              </a>
              <p className="text-xs text-muted-foreground mt-2">{videoUrl}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
