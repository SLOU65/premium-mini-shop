import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Search, Loader2, Video, Users, List, ChevronLeft, ChevronRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function SearchPage() {
  const { t } = useLanguage();
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState("");
  const [searchType, setSearchType] = useState<'video' | 'channel' | 'playlist'>('video');
  const [maxResults, setMaxResults] = useState(20);
  const [sortBy, setSortBy] = useState('relevance');
  const [uploadDate, setUploadDate] = useState('any');
  const [duration, setDuration] = useState('any');
  const [results, setResults] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState(0);

  const searchMutation = trpc.youtube.search.useMutation({
    onSuccess: (data) => {
      setResults(data);
      setCurrentPage(0);
      if (!data.items || data.items.length === 0) {
        toast.info(t('noResults'));
      }
    },
    onError: (error) => {
      if (error.message.includes('No API key')) {
        toast.error(t('pleaseConnectApiKey'));
        setLocation('/api-key');
      } else {
        toast.error(error.message || t('errorSearching'));
      }
    },
  });

  const handleSearch = () => {
    if (!query.trim()) return;
    
    const searchParams: any = {
      query: query.trim(),
      type: searchType,
      maxResults,
    };

    // Add filters if they're not default
    if (sortBy !== 'relevance') searchParams.order = sortBy;
    if (uploadDate !== 'any') searchParams.publishedAfter = getDateFilter(uploadDate);
    if (duration !== 'any') searchParams.videoDuration = duration;

    searchMutation.mutate(searchParams);
  };

  const getDateFilter = (filter: string) => {
    const now = new Date();
    switch (filter) {
      case 'hour':
        return new Date(now.getTime() - 60 * 60 * 1000).toISOString();
      case 'day':
        return new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();
      case 'week':
        return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
      case 'month':
        return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();
      case 'year':
        return new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000).toISOString();
      default:
        return undefined;
    }
  };

  const handleItemClick = (item: any) => {
    if (searchType === 'video') {
      setLocation(`/video/${item.id.videoId}`);
    } else if (searchType === 'channel') {
      setLocation(`/channel/${item.id.channelId || item.snippet.channelId}`);
    }
  };

  const itemsPerPage = 20;
  const paginatedResults = results?.items?.slice(
    currentPage * itemsPerPage,
    (currentPage + 1) * itemsPerPage
  ) || [];
  const totalPages = results?.items ? Math.ceil(results.items.length / itemsPerPage) : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      <div className="container max-w-6xl py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t('back')}
          </Button>
        </Link>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-6 h-6" />
              {t('searchTitle')}
            </CardTitle>
            <CardDescription>{t('searchPlaceholder')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="query">{t('search')}</Label>
              <div className="flex gap-2">
                <Input
                  id="query"
                  placeholder={t('searchPlaceholder')}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  disabled={searchMutation.isPending}
                />
                <Button onClick={handleSearch} disabled={searchMutation.isPending || !query.trim()}>
                  {searchMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Search className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="space-y-2">
                <Label className="text-xs">{t('searchType')}</Label>
                <Select value={searchType} onValueChange={(v: any) => setSearchType(v)}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="video">
                      <div className="flex items-center gap-1">
                        <Video className="w-3 h-3" />
                        {t('video')}
                      </div>
                    </SelectItem>
                    <SelectItem value="channel">
                      <div className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {t('channel')}
                      </div>
                    </SelectItem>
                    <SelectItem value="playlist">
                      <div className="flex items-center gap-1">
                        <List className="w-3 h-3" />
                        {t('playlist')}
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">{t('maxResults')}</Label>
                <Select value={maxResults.toString()} onValueChange={(v) => setMaxResults(Number(v))}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="20">20</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                    <SelectItem value="250">250</SelectItem>
                    <SelectItem value="500">500</SelectItem>
                    <SelectItem value="1000">1000</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Сортировка</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relevance">По релевантности</SelectItem>
                    <SelectItem value="date">По дате</SelectItem>
                    <SelectItem value="viewCount">По просмотрам</SelectItem>
                    <SelectItem value="rating">По рейтингу</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Дата загрузки</Label>
                <Select value={uploadDate} onValueChange={setUploadDate}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Любая</SelectItem>
                    <SelectItem value="hour">За час</SelectItem>
                    <SelectItem value="day">За день</SelectItem>
                    <SelectItem value="week">За неделю</SelectItem>
                    <SelectItem value="month">За месяц</SelectItem>
                    <SelectItem value="year">За год</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Длительность</Label>
                <Select value={duration} onValueChange={setDuration}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Любая</SelectItem>
                    <SelectItem value="short">До 4 мин</SelectItem>
                    <SelectItem value="medium">4-20 мин</SelectItem>
                    <SelectItem value="long">Более 20 мин</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {results && results.items && results.items.length > 0 && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              {paginatedResults.map((item: any, index: number) => (
                <Card
                  key={`${currentPage}-${index}-${item.id.videoId || item.id.channelId || item.id.playlistId}`}
                  className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden"
                  onClick={() => handleItemClick(item)}
                >
                  <div className="aspect-video bg-gray-200 relative overflow-hidden">
                    {item.snippet.thumbnails?.medium?.url && (
                      <img
                        src={item.snippet.thumbnails.medium.url}
                        alt={item.snippet.title}
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className="font-semibold text-sm line-clamp-2 mb-1">{item.snippet.title}</h3>
                    <p className="text-xs text-muted-foreground mb-2">{item.snippet.channelTitle}</p>
                    {item.snippet.publishedAt && (
                      <p className="text-xs text-muted-foreground">
                        {new Date(item.snippet.publishedAt).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </Card>
              ))}
            </div>

            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-4 mb-6">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
                  disabled={currentPage === 0}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm">
                  Страница {currentPage + 1} из {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.min(totalPages - 1, currentPage + 1))}
                  disabled={currentPage === totalPages - 1}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
