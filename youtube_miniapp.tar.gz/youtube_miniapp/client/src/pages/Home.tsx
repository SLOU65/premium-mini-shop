import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Link, useLocation } from "wouter";
import { Globe, Key, Search, History, Youtube, Flame, Compass } from "lucide-react";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Youtube className="w-16 h-16 mx-auto mb-4 text-red-600 animate-pulse" />
          <p className="text-muted-foreground">{t('loading')}</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-blue-50">
        <Card className="w-full max-w-md mx-4">
          <CardHeader className="text-center">
            <Youtube className="w-16 h-16 mx-auto mb-4 text-red-600" />
            <CardTitle className="text-2xl">{t('welcome')}</CardTitle>
            <CardDescription>{t('welcomeDescription')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2 justify-center">
              <Button
                variant={language === 'ru' ? 'default' : 'outline'}
                onClick={() => setLanguage('ru')}
                size="sm"
              >
                🇷🇺 Русский
              </Button>
              <Button
                variant={language === 'en' ? 'default' : 'outline'}
                onClick={() => setLanguage('en')}
                size="sm"
              >
                🇬🇧 English
              </Button>
            </div>
            <Button asChild className="w-full" size="lg">
              <a href={getLoginUrl()}>{t('getStarted')}</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b z-50">
        <div className="container max-w-7xl py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Youtube className="w-8 h-8 text-red-600" />
            <h1 className="text-xl font-bold">YouTube</h1>
          </div>

          <div className="flex-1 max-w-md mx-8">
            <div className="flex gap-2">
              <Input
                placeholder={t('searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="rounded-full"
              />
              <Button onClick={handleSearch} size="icon" className="rounded-full">
                <Search className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant={language === 'ru' ? 'default' : 'outline'}
              onClick={() => setLanguage('ru')}
              size="sm"
            >
              🇷🇺
            </Button>
            <Button
              variant={language === 'en' ? 'default' : 'outline'}
              onClick={() => setLanguage('en')}
              size="sm"
            >
              🇬🇧
            </Button>
            <Button variant="ghost" size="sm">
              {user?.name || user?.email}
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b bg-gray-50">
        <div className="container max-w-7xl flex gap-6 py-3">
          <Link href="/">
            <Button variant="ghost" className="flex items-center gap-2">
              <Compass className="w-4 h-4" />
              {t('home')}
            </Button>
          </Link>
          <Link href="/search">
            <Button variant="ghost" className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              {t('search')}
            </Button>
          </Link>
          <Link href="/api-key">
            <Button variant="ghost" className="flex items-center gap-2">
              <Key className="w-4 h-4" />
              {t('apiKey')}
            </Button>
          </Link>
          <Link href="/history">
            <Button variant="ghost" className="flex items-center gap-2">
              <History className="w-4 h-4" />
              {t('history')}
            </Button>
          </Link>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container max-w-7xl py-8">
        {/* Trending Section */}
        <section className="mb-12">
          <div className="flex items-center gap-2 mb-6">
            <Flame className="w-6 h-6 text-orange-500" />
            <h2 className="text-2xl font-bold">{t('trendingNow')}</h2>
          </div>
          <p className="text-muted-foreground mb-4">
            {t('recommendedForYou')}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">{t('video')}</CardTitle>
                <CardDescription>{language === 'ru' ? 'Найдите видео по ключевым словам' : 'Find videos by keywords'}</CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/search">
                  <Button className="w-full">{t('watchMore')}</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">{t('channel')}</CardTitle>
                <CardDescription>{language === 'ru' ? 'Найдите интересующие вас каналы' : 'Find channels you like'}</CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/search">
                  <Button className="w-full">{t('viewChannel')}</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">{t('history')}</CardTitle>
                <CardDescription>{language === 'ru' ? 'Просмотрите вашу историю поиска' : 'View your search history'}</CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/history">
                  <Button className="w-full">{t('historyTitle')}</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Features Section */}
        <section>
          <h2 className="text-2xl font-bold mb-6">{language === 'ru' ? 'Возможности' : 'Features'}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-5 h-5" />
                  {language === 'ru' ? 'Расширенный поиск' : 'Advanced Search'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {language === 'ru' ? 'Поиск до 1000 результатов с фильтрами по дате, длительности, сортировке и качеству' : 'Search up to 1000 results with filters by date, duration, sorting and quality'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Youtube className="w-5 h-5" />
                  {t('videoDetails')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {language === 'ru' ? 'Просмотрите подробную информацию о видео, включая статистику просмотров, лайков и комментариев' : 'View detailed video information including views, likes and comments statistics'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  {t('channelDetails')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {language === 'ru' ? 'Получите информацию о каналах, включая количество подписчиков и видео' : 'Get channel information including subscriber count and total videos'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  {t('apiKey')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {language === 'ru' ? 'Подключите свой YouTube API ключ для доступа ко всем функциям приложения' : 'Connect your YouTube API key to access all app features'}
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  );
}
