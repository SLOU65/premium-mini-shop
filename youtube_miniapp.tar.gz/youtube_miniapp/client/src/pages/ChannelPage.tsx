import { useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Link, useParams } from "wouter";
import { ArrowLeft, Loader2, Users, Video, Eye, ExternalLink } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ChannelPage() {
  const { channelId } = useParams<{ channelId: string }>();
  const { t } = useLanguage();

  const channelMutation = trpc.youtube.getChannel.useMutation({
    onError: (error) => {
      toast.error(error.message || t('errorLoadingData'));
    },
  });

  useEffect(() => {
    if (channelId) {
      channelMutation.mutate({ channelId });
    }
  }, [channelId]);

  const channel = channelMutation.data;
  const channelUrl = `https://www.youtube.com/channel/${channelId}`;

  const formatNumber = (num?: number) => {
    if (!num) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  if (channelMutation.isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!channel) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">{t('errorLoadingData')}</p>
          <Link href="/search">
            <Button className="mt-4">{t('back')}</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      <div className="container max-w-4xl py-8">
        <Link href="/search">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t('back')}
          </Button>
        </Link>

        <Card>
          <CardHeader>
            <div className="flex items-start gap-4">
              {channel.snippet?.thumbnails?.high?.url && (
                <img
                  src={channel.snippet.thumbnails.high.url}
                  alt={channel.snippet.title || ''}
                  className="w-24 h-24 rounded-full"
                />
              )}
              <div className="flex-1">
                <CardTitle className="text-2xl">{channel.snippet?.title}</CardTitle>
                <CardDescription>{channel.snippet?.customUrl}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-wrap gap-3">
              <Badge variant="secondary" className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                {formatNumber(channel.statistics?.subscriberCount as any)} {t('subscribers')}
              </Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Video className="w-4 h-4" />
                {formatNumber(channel.statistics?.videoCount as any)} {t('totalVideos')}
              </Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                {formatNumber(channel.statistics?.viewCount as any)} {t('totalViews')}
              </Badge>
            </div>

            {channel.snippet?.publishedAt && (
              <div className="text-sm text-muted-foreground">
                {t('published')}: {new Date(channel.snippet.publishedAt).toLocaleDateString()}
              </div>
            )}

            <Separator />

            <div>
              <h3 className="font-semibold mb-2">{t('description')}</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-6">
                {channel.snippet?.description}
              </p>
            </div>

            {channel.snippet?.country && (
              <>
                <Separator />
                <div className="text-sm">
                  <span className="font-semibold">Страна: </span>
                  {channel.snippet.country}
                </div>
              </>
            )}

            <Separator />

            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Перейти на канал</h3>
              <a
                href={channelUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                Открыть на YouTube
              </a>
              <p className="text-xs text-muted-foreground mt-2">{channelUrl}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
