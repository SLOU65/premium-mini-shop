import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Link } from "wouter";
import { ArrowLeft, Key, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ApiKeyPage() {
  const { user, loading: authLoading } = useAuth();
  const { t } = useLanguage();
  const [apiKey, setApiKey] = useState("");
  
  const { data: apiKeyStatus, isLoading: statusLoading, refetch } = trpc.youtube.getApiKeyStatus.useQuery(
    undefined,
    { enabled: !!user }
  );

  const saveApiKeyMutation = trpc.youtube.saveApiKey.useMutation({
    onSuccess: () => {
      toast.success(t('success'));
      setApiKey("");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || t('errorSavingApiKey'));
    },
  });

  const deleteApiKeyMutation = trpc.youtube.deleteApiKey.useMutation({
    onSuccess: () => {
      toast.success(t('success'));
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || t('error'));
    },
  });

  const handleSaveApiKey = () => {
    if (!apiKey.trim()) {
      toast.error(t('apiKeyRequired'));
      return;
    }
    saveApiKeyMutation.mutate({ apiKey: apiKey.trim() });
  };

  const handleDeleteApiKey = () => {
    if (confirm(t('disconnectApiKey') + '?')) {
      deleteApiKeyMutation.mutate();
    }
  };

  if (authLoading || statusLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      <div className="container max-w-2xl py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t('back')}
          </Button>
        </Link>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Key className="w-8 h-8 text-blue-600" />
              <div>
                <CardTitle>{t('apiKeyTitle')}</CardTitle>
                <CardDescription>{t('apiKeyDescription')}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {apiKeyStatus?.hasApiKey ? (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="ml-2">
                  <div className="flex items-center justify-between">
                    <span className="text-green-800">{t('apiKeyConnected')}</span>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={handleDeleteApiKey}
                      disabled={deleteApiKeyMutation.isPending}
                    >
                      {deleteApiKeyMutation.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        t('disconnectApiKey')
                      )}
                    </Button>
                  </div>
                  {apiKeyStatus.createdAt && (
                    <div className="text-xs text-green-700 mt-2">
                      {new Date(apiKeyStatus.createdAt).toLocaleString()}
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="border-yellow-200 bg-yellow-50">
                <XCircle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="ml-2 text-yellow-800">
                  {t('apiKeyNotConnected')}
                </AlertDescription>
              </Alert>
            )}

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="apiKey">{t('enterApiKey')}</Label>
                <Input
                  id="apiKey"
                  type="password"
                  placeholder={t('apiKeyPlaceholder')}
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  disabled={saveApiKeyMutation.isPending}
                />
              </div>

              <Button
                onClick={handleSaveApiKey}
                disabled={saveApiKeyMutation.isPending || !apiKey.trim()}
                className="w-full"
              >
                {saveApiKeyMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {t('loading')}
                  </>
                ) : (
                  t('connectApiKey')
                )}
              </Button>
            </div>

            <div className="border-t pt-4">
              <h3 className="font-semibold mb-2">{t('howToGetApiKey')}</h3>
              <p className="text-sm text-muted-foreground">
                {t('apiKeyInstructions')}
              </p>
              <Button
                variant="link"
                className="px-0 mt-2"
                asChild
              >
                <a
                  href="https://console.cloud.google.com/apis/credentials"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Google Cloud Console →
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
