export type Language = 'ru' | 'en';

export const translations = {
  ru: {
    // Common
    loading: 'Загрузка...',
    error: 'Ошибка',
    success: 'Успешно',
    save: 'Сохранить',
    cancel: 'Отмена',
    delete: 'Удалить',
    search: 'Поиск',
    back: 'Назад',
    
    // Navigation
    home: 'Главная',
    apiKey: 'API Ключ',
    history: 'История',
    settings: 'Настройки',
    trending: 'Популярное',
    recommendations: 'Рекомендации',
    
    // Home page
    welcome: 'Добро пожаловать',
    welcomeDescription: 'YouTube API мини-приложение для Telegram',
    getStarted: 'Начать',
    changeLanguage: 'Сменить язык',
    
    // API Key page
    apiKeyTitle: 'YouTube API Ключ',
    apiKeyDescription: 'Подключите свой YouTube API ключ для доступа к расширенным функциям',
    enterApiKey: 'Введите API ключ',
    apiKeyPlaceholder: 'AIzaSy...',
    connectApiKey: 'Подключить ключ',
    apiKeyConnected: 'API ключ подключен',
    apiKeyNotConnected: 'API ключ не подключен',
    disconnectApiKey: 'Отключить ключ',
    invalidApiKey: 'Неверный API ключ',
    apiKeyRequired: 'Требуется API ключ',
    howToGetApiKey: 'Как получить API ключ?',
    apiKeyInstructions: 'Перейдите в Google Cloud Console, создайте проект и включите YouTube Data API v3',
    
    // Search page
    searchTitle: 'Поиск на YouTube',
    searchPlaceholder: 'Введите запрос...',
    searchType: 'Тип поиска',
    video: 'Видео',
    channel: 'Канал',
    playlist: 'Плейлист',
    maxResults: 'Максимум результатов',
    noResults: 'Результаты не найдены',
    
    // Video details
    videoDetails: 'Информация о видео',
    views: 'Просмотры',
    likes: 'Лайки',
    comments: 'Комментарии',
    published: 'Опубликовано',
    duration: 'Длительность',
    description: 'Описание',
    tags: 'Теги',
    category: 'Категория',
    downloadLinks: 'Ссылки для скачивания',
    getDownloadLink: 'Получить ссылку',
    bestQuality: 'Лучшее качество',
    audioOnly: 'Только аудио',
    
    // Channel details
    channelDetails: 'Информация о канале',
    subscribers: 'Подписчики',
    totalVideos: 'Всего видео',
    totalViews: 'Всего просмотров',
    
    // History
    historyTitle: 'История',
    noHistory: 'История пуста',
    clearHistory: 'Очистить историю',
    
    // Recommendations
    recommendationsTitle: 'Рекомендации',
    trendingNow: 'Популярно сейчас',
    recommendedForYou: 'Рекомендуется для вас',
    watchMore: 'Смотреть ещё',
    viewChannel: 'Перейти на канал',
    
    // Errors
    errorLoadingData: 'Ошибка загрузки данных',
    errorSavingApiKey: 'Ошибка сохранения API ключа',
    errorSearching: 'Ошибка поиска',
    pleaseConnectApiKey: 'Пожалуйста, подключите API ключ',
  },
  en: {
    // Common
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    search: 'Search',
    back: 'Back',
    
    // Navigation
    home: 'Home',
    apiKey: 'API Key',
    history: 'History',
    settings: 'Settings',
    trending: 'Trending',
    recommendations: 'Recommendations',
    
    // Home page
    welcome: 'Welcome',
    welcomeDescription: 'YouTube API Mini App for Telegram',
    getStarted: 'Get Started',
    changeLanguage: 'Change Language',
    
    // API Key page
    apiKeyTitle: 'YouTube API Key',
    apiKeyDescription: 'Connect your YouTube API key to access extended features',
    enterApiKey: 'Enter API Key',
    apiKeyPlaceholder: 'AIzaSy...',
    connectApiKey: 'Connect Key',
    apiKeyConnected: 'API Key Connected',
    apiKeyNotConnected: 'API Key Not Connected',
    disconnectApiKey: 'Disconnect Key',
    invalidApiKey: 'Invalid API Key',
    apiKeyRequired: 'API Key Required',
    howToGetApiKey: 'How to get API Key?',
    apiKeyInstructions: 'Go to Google Cloud Console, create a project and enable YouTube Data API v3',
    
    // Search page
    searchTitle: 'Search YouTube',
    searchPlaceholder: 'Enter search query...',
    searchType: 'Search Type',
    video: 'Video',
    channel: 'Channel',
    playlist: 'Playlist',
    maxResults: 'Max Results',
    noResults: 'No results found',
    
    // Video details
    videoDetails: 'Video Details',
    views: 'Views',
    likes: 'Likes',
    comments: 'Comments',
    published: 'Published',
    duration: 'Duration',
    description: 'Description',
    tags: 'Tags',
    category: 'Category',
    downloadLinks: 'Download Links',
    getDownloadLink: 'Get Download Link',
    bestQuality: 'Best Quality',
    audioOnly: 'Audio Only',
    
    // Channel details
    channelDetails: 'Channel Details',
    subscribers: 'Subscribers',
    totalVideos: 'Total Videos',
    totalViews: 'Total Views',
    
    // History
    historyTitle: 'History',
    noHistory: 'No history',
    clearHistory: 'Clear History',
    
    // Recommendations
    recommendationsTitle: 'Recommendations',
    trendingNow: 'Trending Now',
    recommendedForYou: 'Recommended For You',
    watchMore: 'Watch More',
    viewChannel: 'Visit Channel',
    
    // Errors
    errorLoadingData: 'Error loading data',
    errorSavingApiKey: 'Error saving API key',
    errorSearching: 'Error searching',
    pleaseConnectApiKey: 'Please connect API key',
  },
};

export type TranslationKey = keyof typeof translations.en;
